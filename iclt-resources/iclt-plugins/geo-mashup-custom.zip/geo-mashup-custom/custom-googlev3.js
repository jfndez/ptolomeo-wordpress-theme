/**
 * An example of applying custom styles to a Geo Mashup Google V3 map.
 * 
 * There's a wizard for making your own style arrays at https://gmaps-samples-v3.googlecode.com/svn/trunk/styledmaps/wizard/index.html
 **/


GeoMashup.addAction( 'loadedMap', function( properties, map ) {
	var google_map = map.getMap();
	var custom_styles = [];
	var map_type = new google.maps.StyledMapType( custom_styles, { name: 'custom' } );

	google_map.mapTypes.set( 'custom', map_type );
	google_map.setMapTypeId( 'custom' );
} );




GeoMashup.addAction( 'newMap', function( properties, mxn ) {

	mxn.getMap().setOptions( { maxZoom: 18 } );

} );
