<?php
/**
 * This is the default template for the info window in Geo Mashup maps. 
 *
 * Don't modify this file! It will be overwritten by upgrades.
 *
 * Instead, copy this file to "geo-mashup-info-window.php" in your theme directory, 
 * or info-window.php in the Geo Mashup Custom plugin directory, if you have that 
 * installed. Those files take precedence over this one.
 *
 * For styling of the info window, see map-style-default.css.
 *
 * @package GeoMashup
 */

// A potentially heavy-handed way to remove shortcode-like content

add_filter( 'the_excerpt', array( 'GeoMashupQuery', 'strip_brackets' ) );

?>
<div class="locationinfo post-location-info">
<?php if (have_posts()) : ?>

	<?php while (have_posts()) : the_post(); ?>
	
		<table style="width:100%;" cellpadding="3" cellspacing="3">
	<tr>
		<td><?php if ( has_post_thumbnail() ) :?><br>
            <a href="<?php the_permalink() ?>"><center><?php the_post_thumbnail('mini-cartografia', array(
                        'alt'	=> trim(strip_tags( $post->post_title )),
                        'title'	=> trim(strip_tags( $post->post_title )),
                    )); ?></center></a>&nbsp;
            <?php endif; ?>

		<table>
	<tr>
		


	</tr>
</table>
		</td>
		<td><h2><a href="<?php the_permalink() ?>" title="<?php the_title_attribute(); ?>"><?php the_title(); ?></a></h2>

<?php
$my_meta = get_post_meta($post->ID,'_my_meta',TRUE);

if (!empty($my_meta['name'])) {
echo 'Dirección: '.$my_meta['name'].'<br>';
			}
?>

<?php 
    $term_list = get_the_term_list( get_the_ID(), 'localidad' );
    if(!empty($term_list)):
?>Localidad: <?php echo get_the_term_list( $post->ID, 'localidad', '', ', ' ); ?><?php endif ;?>

<?php 
    $term_list = get_the_term_list( get_the_ID(), 'region' );
    if(!empty($term_list)):
?>(<?php echo get_the_term_list( $post->ID, 'region', '', ', ' ); ?>)<?php endif ;?> <?php echo get_the_term_list( $post->ID, 'responsable', '<br>Responsabilidad: ', ' | ' ); ?> <?php echo get_the_term_list( $post->ID, 'fecha', '<br>Fecha: ', ', ' ); ?>

<?php if ( !empty( $post->post_content) ) :?>
<?php $content = get_the_content();
      $content = strip_tags($content);
      echo '<br><br>'.substr($content, 0, 150).' [...] <br>';
?>
<?php endif ;?>

<br><br><a class="readmore" href="<?php the_permalink() ?>" title="<?php the_title_attribute(); ?>">Leer más</a> </footer></td>
	</tr>
</table>


	


	<?php endwhile; ?>

<?php else : ?>

	<h2 class="center">Not Found</h2>
	<p class="center">Sorry, but you are looking for something that isn't here.</p>

<?php endif; ?>

</div>
